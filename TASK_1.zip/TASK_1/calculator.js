const num1 = parseInt(prompt("Enter 1st number"));
const num2 = parseInt(prompt("Enter 2nd number"));
const userinput = prompt("Enter +, -,* , / \n" )

function calculator(num1, num2) {
  if (userinput == "+"){
   console.log("The sum of", num1 ,"and", num2 ,"is", num1 + num2);
  }
  else if( userinput == "-"){
      console.log("The subtartction of ", num1 ,"and", num2, "is", num1 - num2);
  }
  else if( userinput == "*"){
      console.log("The multiplction of", num1, "and", num2, "is", num1 * num2);
  }
  else if( userinput == "/"){
      console.log("The division of", num1, "and", num2, "is", num1 /num2);
  }
  else{
      console.log("Enter a correct input")
  }
}

calculator(num1, num2);
