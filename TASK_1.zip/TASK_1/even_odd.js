const num = parseInt(prompt("Check its ODD or Even"));



function myFunction() {
 if (num/2 == 0){
     console.log("Number", num, "is a Even number");
 }
 else if(num/2 != 0){
     console.log("Number", num, "is a Odd number")
 }
}

myFunction();
